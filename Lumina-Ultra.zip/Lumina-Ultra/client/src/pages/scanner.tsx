import { ARCanvas } from "@/components/ARCanvas";

export default function Scanner() {
  return <ARCanvas />;
}
