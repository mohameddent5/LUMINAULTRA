export {};

declare global {
  interface Window {
    FaceLandmarker: any;
    FilesetResolver: any;
    DrawingUtils: any;
  }
}
